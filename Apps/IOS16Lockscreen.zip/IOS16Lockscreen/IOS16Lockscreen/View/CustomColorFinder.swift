//
//  CustomColorFinder.swift
//  IOS16Lockscreen
//
//  Created by Fabian Kuschke on 16.08.22.
//

import SwiftUI
//MARK: This view will return color based on the xy coordinates
struct CustomColorFinder: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

//struct CustomColorFinder_Previews: PreviewProvider {
//    static var previews: some View {
//        CustomColorFinder()
//    }
//}
