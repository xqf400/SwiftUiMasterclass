//
//  IOS16LockscreenApp.swift
//  IOS16Lockscreen
//
//  Created by Fabian Kuschke on 16.08.22.
//

import SwiftUI

@main
struct IOS16LockscreenApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
